"""
My First Example
==================

This is a simple plot example.

"""
import matplotlib.pyplot as plt

plt.plot([0, 1], [0, 1])
plt.title("Simple Plot")
plt.show()
